<html>
<!--<head>Contraoller dan View</head>-->
<head><tiitle>Controller, Model dan View</head>
<body>
	<h2><? echo $teks; ?></h2>
	<h3>Menggunakan Controller dan View!</h3>
</body>
</html>